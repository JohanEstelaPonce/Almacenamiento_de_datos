/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ventana;

import javax.swing.JOptionPane;

/**
 *
 * @author USUARIO
 */
public class Calculadora extends javax.swing.JFrame {

    /**
     * Creates new form interfaz
     */
    public Calculadora() {
        initComponents();
        this.setLocationRelativeTo(null);
        convdecimal.setEnabled(false);
        convhexa.setEnabled(false);
        convbinario.setEnabled(false);
        convoctal.setEnabled(false);
        
        
        // GRUPO DE RADIO BOTONES
        rbotones.add(decimal);
        rbotones.add(binario);
        rbotones.add(octal);
        rbotones.add(hexadecimal);
        
    }
    
    // DECIMAL A HEXADECIMAL
    
    public static String decimalToHex(int decimal) {
        String hexChar = "0123456789ABCDEF";
        String hex = "";
        for( int i=0; decimal > 0; i++) {
            int remainder = decimal % 16;
            hex = hex + hexChar.charAt(remainder) ; // Agregar a la izquierda
            decimal /= 16;

        }
        return invertString(hex);
    }
    
    public static String invertString(String word){
        String invertedWord = "";
        for (int index = word.length() - 1; index >= 0; index--) {
            invertedWord += word.charAt(index);
        }
        return invertedWord;
    }
    
    // HEXADECIMAL A DECIMAL
    
    public static long hexadecimalADecimal(String hex) {
        long decimal = 0;
        int power = 0;
        for (int i = hex.length() - 1; i >= 0; i--) {
            int value = charHoistingHexToDec(hex.charAt(i));
            long partialNum = (long) Math.pow(16, power) * value;
            decimal += partialNum;
            power++;
        }
        return decimal;
    }
    
    public static int charHoistingHexToDec(char a) {
        switch (a) {
            case 'A':
                return 10;
            case 'B':
                return 11;
            case 'C':
                return 12;
            case 'D':
                return 13;
            case 'E':
                return 14;
            case 'F':
                return 15;
            default:
                return Integer.parseInt(String.valueOf(a));
        }
    }
    
    // CONVERSIONES
    
    public static String decimalaBinario(int decimal) {
        String binario = "";
        while (decimal>0) {
            binario =decimal % 2 + binario;
            decimal =decimal / 2;
        }
        return binario;
    }

    public static String decimalaOctal(int decimal) {
        int residuo;
        String octal = "";
        char[] caracteresOctales = {'0', '1', '2', '3', '4', '5', '6', '7'};
        while (decimal>0) {
            residuo=decimal%8;
            char caracter = caracteresOctales[residuo];
            octal = caracter + octal;
            decimal = decimal / 8;
        }
        return octal;
    }
   
    public static int binarioaDecimal(int binario) {
        int decimal = 0;
        int potencia = 0;
        
        while (true) {
            if (binario == 0) {
                //salida del bucle
                break;
            } else {
                int temp = binario % 10;
                decimal += temp * Math.pow(2, potencia);
                binario = binario / 10;
                potencia++;
            }
        }
        return decimal;
    }

    public static int octalaDecimal(int octal) {
        int decimal = 0;
        int potencia = 0;
        
        while (true) {
            if (octal == 0) {
                break;
            } else {
                int temp = octal % 10;
                decimal += temp * Math.pow(8, potencia);
                octal = octal / 10;
                potencia++;
            }
        }
        return decimal;
    }
    
    
    
    //VALIDACIONES DE NÚMEROS
    
    public static boolean validarDecimal(int decimal) {
    // Decimal pasa la validación con el hecho de que sea entero
        return true;
    }

    public static boolean validarBinario(int binario) {
    // Comprobar si solo se compone de unos y ceros
        String binarioComoCadena = String.valueOf(binario);
        for (int i = 0; i < binarioComoCadena.length(); i++) {
            char caracter = binarioComoCadena.charAt(i);
            if (caracter != '0' && caracter != '1') {
                return false;
            }
        }
        return true;
    }
    
    public static boolean validarOctal(int octal) {
    // comprobar si solo tiene números del 0 al 7
        String octalComoCadena = String.valueOf(octal);
        String caracteresOctales = "01234567";
        for (int i = 0; i < octalComoCadena.length(); i++) {
            char caracter = octalComoCadena.charAt(i);
            // Si no se encuentra dentro de los caracteres válidos, regresamos false
            if (caracteresOctales.indexOf(caracter) == -1) {
                return false;
            }
        }
        return true;
    }
    
    public static boolean validarHexadecimal(String hexadecimal) {
        // Comprobar si solo tiene números del 0 al 9 y letras de la A a la F
        String caracteresHexadecimales = "0123456789ABCDEF";
        for (int i = 0; i < hexadecimal.length(); i++) {
            char caracter = hexadecimal.charAt(i);
            // Si no se encuentra dentro de los caracteres válidos, regresamos false
            if (caracteresHexadecimales.indexOf(caracter) == -1) {
                return false;
            }
        }
        return true;
    }
    
    // VALIDACION PRINCIPAL
    
    public boolean validacion(String cadena) {
        int num;
        try {
            num = Integer.parseInt(cadena);
            return true;
        } catch (Exception e) {
            return false;
        }
    }
    
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        rbotones = new javax.swing.ButtonGroup();
        jText_titulo = new javax.swing.JTextField();
        convhexa = new javax.swing.JButton();
        convoctal = new javax.swing.JButton();
        convdecimal = new javax.swing.JButton();
        convbinario = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jButton_limpiar = new javax.swing.JButton();
        jButton_limpiar_1 = new javax.swing.JButton();
        convertido = new javax.swing.JTextField();
        aconvertir = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        hexadecimal = new javax.swing.JRadioButton();
        decimal = new javax.swing.JRadioButton();
        binario = new javax.swing.JRadioButton();
        jLabel5 = new javax.swing.JLabel();
        octal = new javax.swing.JRadioButton();
        jLabel7 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jText_titulo.setBackground(new java.awt.Color(0, 51, 204));
        jText_titulo.setFont(new java.awt.Font("Vineta BT", 0, 28)); // NOI18N
        jText_titulo.setForeground(new java.awt.Color(255, 255, 255));
        jText_titulo.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jText_titulo.setText("CONVERSIÓN DE SISTEMAS NUMÉRICOS");
        jText_titulo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jText_tituloActionPerformed(evt);
            }
        });
        getContentPane().add(jText_titulo, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 920, 70));

        convhexa.setFont(new java.awt.Font("Nirmala UI", 0, 22)); // NOI18N
        convhexa.setText("HEXADECIMAL");
        convhexa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                convhexaActionPerformed(evt);
            }
        });
        getContentPane().add(convhexa, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 450, 190, 60));

        convoctal.setBackground(new java.awt.Color(255, 255, 255));
        convoctal.setFont(new java.awt.Font("Nirmala UI", 0, 24)); // NOI18N
        convoctal.setText("OCTAL");
        convoctal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                convoctalActionPerformed(evt);
            }
        });
        getContentPane().add(convoctal, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 380, 150, 60));

        convdecimal.setBackground(new java.awt.Color(255, 255, 255));
        convdecimal.setFont(new java.awt.Font("Nirmala UI", 0, 24)); // NOI18N
        convdecimal.setForeground(new java.awt.Color(0, 0, 51));
        convdecimal.setText("DECIMAL");
        convdecimal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                convdecimalActionPerformed(evt);
            }
        });
        getContentPane().add(convdecimal, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 380, 150, 60));

        convbinario.setFont(new java.awt.Font("Nirmala UI", 0, 24)); // NOI18N
        convbinario.setText("BINARIO");
        convbinario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                convbinarioActionPerformed(evt);
            }
        });
        getContentPane().add(convbinario, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 440, 150, 60));

        jLabel2.setFont(new java.awt.Font("Arial Black", 0, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 0, 0));
        jLabel2.setText("OUTPUT");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 580, 90, 20));

        jButton_limpiar.setBackground(new java.awt.Color(0, 0, 0));
        jButton_limpiar.setFont(new java.awt.Font("Arial Black", 0, 24)); // NOI18N
        jButton_limpiar.setForeground(new java.awt.Color(0, 255, 204));
        jButton_limpiar.setText("PORTADA");
        jButton_limpiar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_limpiarActionPerformed(evt);
            }
        });
        getContentPane().add(jButton_limpiar, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 610, 200, 50));

        jButton_limpiar_1.setBackground(new java.awt.Color(0, 0, 0));
        jButton_limpiar_1.setFont(new java.awt.Font("Arial Black", 0, 24)); // NOI18N
        jButton_limpiar_1.setForeground(new java.awt.Color(0, 255, 204));
        jButton_limpiar_1.setText("LIMPIAR");
        jButton_limpiar_1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_limpiar_1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton_limpiar_1, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 610, 200, 50));

        convertido.setEditable(false);
        convertido.setFont(new java.awt.Font("Dialog", 0, 36)); // NOI18N
        convertido.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        getContentPane().add(convertido, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 480, 280, 90));

        aconvertir.setEditable(false);
        aconvertir.setFont(new java.awt.Font("Dialog", 0, 36)); // NOI18N
        aconvertir.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        aconvertir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                aconvertirActionPerformed(evt);
            }
        });
        getContentPane().add(aconvertir, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 240, 280, 90));

        jLabel4.setFont(new java.awt.Font("Arial Black", 0, 18)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 0, 0));
        jLabel4.setText("INPUT");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 210, 70, 20));

        hexadecimal.setBackground(new java.awt.Color(153, 255, 51));
        hexadecimal.setFont(new java.awt.Font("Nirmala UI", 1, 24)); // NOI18N
        hexadecimal.setText("HEXADECIMAL");
        hexadecimal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                hexadecimalActionPerformed(evt);
            }
        });
        getContentPane().add(hexadecimal, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 100, 200, 60));

        decimal.setBackground(new java.awt.Color(153, 255, 51));
        decimal.setFont(new java.awt.Font("Nirmala UI", 1, 24)); // NOI18N
        decimal.setText("DECIMAL");
        decimal.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 5));
        decimal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                decimalActionPerformed(evt);
            }
        });
        getContentPane().add(decimal, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 100, 140, 60));

        binario.setBackground(new java.awt.Color(153, 255, 51));
        binario.setFont(new java.awt.Font("Nirmala UI", 1, 24)); // NOI18N
        binario.setText("BINARIO");
        binario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                binarioActionPerformed(evt);
            }
        });
        getContentPane().add(binario, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 150, 140, 60));

        jLabel5.setFont(new java.awt.Font("Geometr415 Blk BT", 1, 18)); // NOI18N
        jLabel5.setText("A BASE");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 350, 70, 20));

        octal.setBackground(new java.awt.Color(153, 255, 51));
        octal.setFont(new java.awt.Font("Nirmala UI", 1, 24)); // NOI18N
        octal.setText("OCTAL");
        octal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                octalActionPerformed(evt);
            }
        });
        getContentPane().add(octal, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 150, 110, 60));

        jLabel7.setFont(new java.awt.Font("Geometr415 Blk BT", 1, 18)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(51, 0, 51));
        jLabel7.setText("CONVERTIR DE BASE");
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 100, -1, 20));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagen/wp2912337.jpg"))); // NOI18N
        jLabel1.setText("jLabel1");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 70, 920, 610));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jText_tituloActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jText_tituloActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jText_tituloActionPerformed

    private void jButton_limpiar_1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_limpiar_1ActionPerformed
        convertido.setText("");
        aconvertir.setText("");
        convertido.setText("");
        aconvertir.setEditable(false);
        convertido.setEditable(false);
        convdecimal.setEnabled(false);
        convhexa.setEnabled(false);
        convbinario.setEnabled(false);
        convoctal.setEnabled(false);
        rbotones.clearSelection();
    }//GEN-LAST:event_jButton_limpiar_1ActionPerformed

    private void jButton_limpiarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_limpiarActionPerformed
        Portada p = new Portada();
        
        p.setVisible(true);
        p.setLocationRelativeTo(null);
        
        this.dispose();
    }//GEN-LAST:event_jButton_limpiarActionPerformed

    private void decimalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_decimalActionPerformed
        if (decimal.isSelected()) {
            aconvertir.setEditable(true);
            convbinario.setEnabled(true);
            convdecimal.setEnabled(true);
            convhexa.setEnabled(true);
            convoctal.setEnabled(true);
        }
    }//GEN-LAST:event_decimalActionPerformed

    private void binarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_binarioActionPerformed
        if (binario.isSelected()) {
            aconvertir.setEditable(true);
            convbinario.setEnabled(true);
            convdecimal.setEnabled(true);
            convhexa.setEnabled(true);
            convoctal.setEnabled(true);
        }
    }//GEN-LAST:event_binarioActionPerformed

    private void octalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_octalActionPerformed
        if (octal.isSelected()) {
            aconvertir.setEditable(true);
            convbinario.setEnabled(true);
            convdecimal.setEnabled(true);
            convhexa.setEnabled(true);
            convoctal.setEnabled(true);
        }
    }//GEN-LAST:event_octalActionPerformed

    private void hexadecimalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_hexadecimalActionPerformed
        if (hexadecimal.isSelected()) {
            aconvertir.setEditable(true);
            convbinario.setEnabled(true);
            convdecimal.setEnabled(true);
            convhexa.setEnabled(true);
            convoctal.setEnabled(true);
        }
    }//GEN-LAST:event_hexadecimalActionPerformed

    private void convbinarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_convbinarioActionPerformed
        
        int numdecimal, numoctal, numbinario;
        
        if (aconvertir.getText().equals("")) {
            JOptionPane.showMessageDialog(null, "Coloque el número a convertir");
        } else {
            
            convertido.setEditable(true);
            
            if (decimal.isSelected()) {
                
                if (validacion(aconvertir.getText()) == true) {
                    
                    String valor = aconvertir.getText();
                        String hexadecimal=valor;
                        int baseInput = 10;
                        int baseOut = 2;
                        switch(baseInput){
                        default:
                            int decimalOut = 0;
                            int potencia = 0;
                            int octal=Integer.parseInt(valor);
                            while (true) {
                                if (octal == 0) {
                                    break;
                                } else {
                                    int temp = octal % 10;
                                    decimalOut += temp * Math.pow(baseInput, potencia);
                                    octal = octal / 10;
                                    potencia++;
                                }
                            }       
                            convertido.setText(Integer.toString(decimalOut,baseOut));break;
                        }
                    
//                    numdecimal = Integer.parseInt(aconvertir.getText()); 
//                    convertido.setText(decimalaBinario(numdecimal));
                } else {
                    convertido.setText("");
                    JOptionPane.showMessageDialog(null, "El número no esta en base decimal");
                }   
            }
            
            if (binario.isSelected()) {
                
                if (validacion(aconvertir.getText()) == true) {
                    
                    numbinario = Integer.parseInt(aconvertir.getText());

                    if (validarBinario(numbinario) == true) {
                    
                        convertido.setText(aconvertir.getText());
                        JOptionPane.showMessageDialog(null, "El resultado es el mismo número que ingresó\nSeleccione otra base");
                    
                    } else {
                        convertido.setText("");
                        JOptionPane.showMessageDialog(null, "El número no esta en base binaria");                        
                    }                       
                } else {
                    convertido.setText("");
                    JOptionPane.showMessageDialog(null, "El número no esta en base binaria");  
                }
            }
            
            if (octal.isSelected()) {
                
                if (validacion(aconvertir.getText()) == true) {
                    
                    numoctal = Integer.parseInt(aconvertir.getText());
                    
                    if (validarOctal(numoctal) == true) {
                    
                        int dec= octalaDecimal(numoctal);
                        String binarioResultante = decimalaBinario(dec);
                        convertido.setText(binarioResultante);
                    
                    } else {
                        convertido.setText("");
                        JOptionPane.showMessageDialog(null, "El número no esta en base octal");
                    }
                } else {
                    convertido.setText("");
                    JOptionPane.showMessageDialog(null, "El número no esta en base octal");
                }
            }
            
            if (hexadecimal.isSelected()) {
                
                if(validarHexadecimal(aconvertir.getText()) == true) {
                   
                    String r = Long.toString(hexadecimalADecimal(aconvertir.getText()));
                    numdecimal = Integer.parseInt(r); 
                    convertido.setText(decimalaBinario(numdecimal));
                   
                } else {
                    convertido.setText("");
                    JOptionPane.showMessageDialog(null, "El número no esta en base hexadecimal\nRecomendación: Escriba las letras en MAYÚSCULAS");
                }
            }
        }
    }//GEN-LAST:event_convbinarioActionPerformed

    private void convdecimalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_convdecimalActionPerformed
        
        int numbinario, numoctal;
        
        if (aconvertir.getText().equals("")) {
            JOptionPane.showMessageDialog(null, "Coloque el número a convertir");
        } else {
            
            convertido.setEditable(true);
            
            if (decimal.isSelected()) {
                
                if (validacion(aconvertir.getText()) == true) {
                    convertido.setText(aconvertir.getText());
                    JOptionPane.showMessageDialog(null, "El resultado es el mismo número que ingresó\nSeleccione otra base");
                } else {
                    convertido.setText("");
                    JOptionPane.showMessageDialog(null, "El número no esta en base decimal");
                }
            }
            
            if (binario.isSelected()) {
                
                if (validacion(aconvertir.getText()) == true) {
                    
                    numbinario = Integer.parseInt(aconvertir.getText());
                    
                    if (validarBinario(numbinario) == true) {
                        
                        String valor = aconvertir.getText();
                        String hexadecimal=valor;
                        int baseInput = 2;
                        int baseOut = 10;
                        switch(baseInput){
                        default:
                            int decimalOut = 0;
                            int potencia = 0;
                            int octal=Integer.parseInt(valor);
                            while (true) {
                                if (octal == 0) {
                                    break;
                                } else {
                                    int temp = octal % 10;
                                    decimalOut += temp * Math.pow(baseInput, potencia);
                                    octal = octal / 10;
                                    potencia++;
                                }
                            }       
                            convertido.setText(Integer.toString(decimalOut,baseOut));break;
                        }

                        //String r = Integer.toString(binarioaDecimal(numbinario));               
                        //convertido.setText(r);
                    
                    } else {
                        convertido.setText("");
                        JOptionPane.showMessageDialog(null, "El número no esta en base binaria");
                    }
                } else {
                    convertido.setText("");
                    JOptionPane.showMessageDialog(null, "El número no esta en base binaria");
                }
            }
            
            if (octal.isSelected()) {
                
                if (validacion(aconvertir.getText()) == true) {
                    
                    numoctal = Integer.parseInt(aconvertir.getText());
                    
                    if (validarOctal(numoctal) == true) {
                    
                        String r3 = Integer.toString(octalaDecimal(numoctal));
                        convertido.setText(r3);
                    
                    } else {
                        convertido.setText("");
                        JOptionPane.showMessageDialog(null, "El número no esta en base octal");
                    }
                } else {
                    convertido.setText("");
                    JOptionPane.showMessageDialog(null, "El número no esta en base octal");
                }  
            }
            
            if (hexadecimal.isSelected()) {
                
                if(validarHexadecimal(aconvertir.getText()) == true) {
                   
                   String r = Long.toString(hexadecimalADecimal(aconvertir.getText()));       
                   convertido.setText(r);
                   
                } else {
                    convertido.setText("");
                    JOptionPane.showMessageDialog(null, "El número no esta en base hexadecimal\nRecomendación: Escriba las letras en MAYÚSCULAS");
                }
            }
        }
    }//GEN-LAST:event_convdecimalActionPerformed

    private void convhexaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_convhexaActionPerformed
       
        int numdecimal, numbinario, numoctal;
        
        if (aconvertir.getText().equals("")) {
            JOptionPane.showMessageDialog(null, "Coloque el número a convertir");
        } else {
            
            convertido.setEditable(true);
            
            if (decimal.isSelected()) {
                
                if (validacion(aconvertir.getText()) == true) {
                    
                    numdecimal = Integer.parseInt(aconvertir.getText()); 
                    
                    if (validarDecimal(numdecimal) == true) {
                        convertido.setText(decimalToHex(numdecimal));
                    } else {
                        convertido.setText("");
                        JOptionPane.showMessageDialog(null, "El número no esta en base decimal");
                    }
                    
                } else {
                    convertido.setText("");
                    JOptionPane.showMessageDialog(null, "El número no esta en base decimal");
                }
            }
            
            if (binario.isSelected()) {
                
                if (validacion(aconvertir.getText()) == true) {
                    
                    numbinario = Integer.parseInt(aconvertir.getText());
                
                    if (validarBinario(numbinario) == true) {
                        int aux = binarioaDecimal(numbinario);
                        convertido.setText(decimalToHex(aux));
                    } else {
                        convertido.setText("");
                        JOptionPane.showMessageDialog(null, "El número no esta en base binaria");
                    }
                    
                } else {
                    convertido.setText("");
                    JOptionPane.showMessageDialog(null, "El número no esta en base binaria");
                }    
            }
            
            if (octal.isSelected()) {
                
                if (validacion(aconvertir.getText()) == true) {
                    
                    numoctal = Integer.parseInt(aconvertir.getText());
                
                    if (validarOctal(numoctal) == true) {
                        int r = octalaDecimal(numoctal);
                        convertido.setText(decimalToHex(r));
                    } else {
                        convertido.setText("");
                        JOptionPane.showMessageDialog(null, "El número no esta en base octal");
                    }
                    
                } else {
                    convertido.setText("");
                    JOptionPane.showMessageDialog(null, "El número no esta en base octal");
                }
            }
            
            if (hexadecimal.isSelected()) { 
                
                 if(validarHexadecimal(aconvertir.getText()) == true) {
                   
                    convertido.setText(aconvertir.getText());
                    JOptionPane.showMessageDialog(null, "El resultado es el mismo número\nSeleccione otra base");
                   
                } else {
                    convertido.setText("");
                    JOptionPane.showMessageDialog(null, "El número no esta en base hexadecimal\nRecomendación: Escriba las letras en MAYÚSCULAS");
                }         
            }
        }
    }//GEN-LAST:event_convhexaActionPerformed

    private void convoctalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_convoctalActionPerformed

        int numdecimal, numbinario, numhexadecimal, numoctal;
        
        if (aconvertir.getText().equals("")) {
            JOptionPane.showMessageDialog(null, "Coloque el número a convertir");
        } else {
            
            convertido.setEditable(true);
            
            if (decimal.isSelected()) {
                
                if (validacion(aconvertir.getText()) == true) {
                    numdecimal = Integer.parseInt(aconvertir.getText());
                    convertido.setText(decimalaOctal(numdecimal));
                } else {
                    convertido.setText("");
                    JOptionPane.showMessageDialog(null, "El número no esta en base decimal");
                }
            }
            
            if (binario.isSelected()) {
                
                if (validacion(aconvertir.getText()) == true) {
                    
                    numbinario = Integer.parseInt(aconvertir.getText());
                    
                    if (validarBinario(numbinario) == true) {
                    
                        int aux = binarioaDecimal(numbinario);
                        String octalResultante = decimalaOctal(aux);
                        convertido.setText(octalResultante);
                    
                    } else {
                        convertido.setText("");
                        JOptionPane.showMessageDialog(null, "El número no esta en base binaria");
                    }
                } else {
                    convertido.setText("");
                    JOptionPane.showMessageDialog(null, "El número no esta en base binaria");
                }
            }
            
            if (octal.isSelected()) {
                
                if (validacion(aconvertir.getText()) == true) {
                    
                    numoctal = Integer.parseInt(aconvertir.getText());
                
                    if (validarOctal(numoctal) == true) {
                        convertido.setText(aconvertir.getText());
                        JOptionPane.showMessageDialog(null, "El resultado es el mismo número\nSeleccione otra base");
                    } else {
                        convertido.setText("");
                        JOptionPane.showMessageDialog(null, "El número no esta en base octal");
                    }
                } else {
                    convertido.setText("");
                    JOptionPane.showMessageDialog(null, "El número no esta en base octal");
                }
                
                
            }
            
            if (hexadecimal.isSelected()) {
                
                if(validarHexadecimal(aconvertir.getText()) == true) {
                   
                    String r = Long.toString(hexadecimalADecimal(aconvertir.getText()));
                    numhexadecimal = Integer.parseInt(r);
                    convertido.setText(decimalaOctal(numhexadecimal));
                   
                } else {
                    convertido.setText("");
                    JOptionPane.showMessageDialog(null, "El número no esta en base hexadecimal\nRecomendación: Escriba las letras en MAYÚSCULAS");
                }
            }
        }
    }//GEN-LAST:event_convoctalActionPerformed

    private void aconvertirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_aconvertirActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_aconvertirActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Calculadora.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Calculadora.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Calculadora.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Calculadora.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Calculadora().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField aconvertir;
    private javax.swing.JRadioButton binario;
    private javax.swing.JButton convbinario;
    private javax.swing.JButton convdecimal;
    private javax.swing.JTextField convertido;
    private javax.swing.JButton convhexa;
    private javax.swing.JButton convoctal;
    private javax.swing.JRadioButton decimal;
    private javax.swing.JRadioButton hexadecimal;
    private javax.swing.JButton jButton_limpiar;
    private javax.swing.JButton jButton_limpiar_1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JTextField jText_titulo;
    private javax.swing.JRadioButton octal;
    private javax.swing.ButtonGroup rbotones;
    // End of variables declaration//GEN-END:variables
}
